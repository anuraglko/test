﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication8.Repository;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication8.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private iFindMultiple _ifindMultiple;
        public ValuesController(iFindMultiple findMultiple)
        {
            _ifindMultiple = findMultiple;
        }



        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
      
        public IActionResult Get(int id)
        {
            string result=  _ifindMultiple.getValue(id);
            
            return new JsonResult(result);
        
            //return "value";
        }


    }
}
