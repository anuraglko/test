﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication8.Repository
{
    public interface iFindMultiple
    {
        public string getValue(int i);
    }
    public class FindMultiple : iFindMultiple
    {
        string iFindMultiple.getValue(int i)
        {
            string result = string.Empty;
            if (i % 15 == 0)
                result = "GN;";
            else if (i % 5 == 0)
                result = "N;";
            else if (i % 3 == 0)
                result = "G";
            else
                result = i.ToString();

            return result;
        }
    }
}
